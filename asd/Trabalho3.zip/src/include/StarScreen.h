#ifndef STARTSCREEN_H
#define STARTSCREEN_H


class StartScreen
{
    public:
        StartScreen();
        ~StartScreen();

    protected:

    private:
};

#endif // STARSCREEN_H
